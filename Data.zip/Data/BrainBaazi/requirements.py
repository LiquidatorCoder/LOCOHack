import os
os.system("sudo apt install adb")
os.system("sudo apt install python-pip")
os.system("sudo apt install tesseract-ocr")
os.system("sudo apt-get install idle")
#os.system("pip install google-search-api")
os.system("pip install pillow")
os.system("pip install pytesseract")

