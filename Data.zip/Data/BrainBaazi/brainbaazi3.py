import time,os,webbrowser,collections
from PIL import Image
import pytesseract

def screenshot():
	os.system("adb shell screencap -p /sdcard/new.jpg")
	os.system("adb pull /sdcard/new.jpg")
	img=Image.open('new.jpg')
	img = img.resize((w,h), Image.NEAREST)
	a_=img.crop([int(q_[0]),int(q_[1]),int(q_[0])+int(q_[2]),int(q_[1])+int(q_[3])])
	a_.save("ques.jpg")
	
def ocr():
	ques = (pytesseract.image_to_string(Image.open('ques.jpg'),lang='eng')).lower()
	ques=ques.replace('\n',' ')
	lis=[ques]
	return lis
def gsearch(quest):
	quote_page ="https://www.google.co.in/search?q=" +quest+ "&oq="+quest+"&gs_l=serp.12..0i71l8.0.0.0.6391.0.0.0.0.0.0.0.0..0.0....0...1c..64.serp..0.0.0.UiQhpfaBsuU"
	webbrowser.open_new(quote_page)
os.system("adb shell screencap -p /sdcard/test.jpg")
os.system("adb pull /sdcard/test.jpg")
AA=Image.open('test.jpg')
w=int(AA.size[0]/2)
h=int(AA.size[1]/2)
p=int(0.027777778*w)
h1=int(0.26041666*h)
h2=int(0.5*h)
h3=int(0.37020833*h)
h4=int(0.578125*h)
h5=int(0.458125*h)
h6=int(0.681875*h)
h7=int(0.531875*h)
h8=int(0.775625*h)
quescoo=str(2*p)+' '+str(h1)+' '+str(int(0.96078*w))+' '+str(int(0.1411458*h))
q_=quescoo.split(' ')
fr=open("abc.txt","r")
c=int(fr.read())
fr.close()
while True:
	q=[]
	a1=''
	a2=''
	a3=''
	lis1=[]
	lis2=[]
	liss=[]
	x=raw_input("===")
	if x=="c":
		break
	start=time.time()
	screenshot()
	lis=ocr()
	gsearch(lis[0])
	print lis[0]
	end=time.time()
	print "Time Elapsed : ",end-start
	os.rename('new.jpg','new'+str(c)+'.jpg')
	c+=1
fw=open("abc.txt","w")
fw.write(str(c))
fw.close()

