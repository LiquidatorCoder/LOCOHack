import time,os,webbrowser,collections
from google import google
from PIL import Image
import pytesseract

AA=Image.open('1234.jpg')
ques = (pytesseract.image_to_string(AA,lang='eng')).lower()
print ques
